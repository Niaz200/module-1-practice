<?php

// This is a code to print something here 
// THis is another line of comment
# This is a code to print something here 
# THis is another line of comment

/*
I can write anything here. I can write anything here. I can write anything here. I can write anything here. I can write anything here. I can write anything here. I can write anything here. I can write anything here. I can write anything here. I can write anything here. I can write anything here. I can write anything here. I can write anything here. I can write anything here. 

Write anything. This is flexible. Write anything. This is flexible. Write anything. This is flexible. Write anything. This is flexible. Write anything. This is flexible. Write anything. This is flexible. Write anything. This is flexible. Write anything. This is flexible. Write anything. This is flexible. Write anything. This is flexible. Write anything. This is flexible. Write anything. This is flexible. Write anything. This is flexible. 

Write anything. This is flexible. 
*/

echo 'This is a test';
?>