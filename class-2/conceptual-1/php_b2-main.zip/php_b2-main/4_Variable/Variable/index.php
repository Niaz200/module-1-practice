<?php
$aa = 10;
$AA = 20;
echo $aa;
echo $AA;
?>