<?php
//$country = 'Bangladesh';
//$country = "Bangladesh";
//echo "Bangladesh is a nice country";
// $x = 20;
// echo is_int($x);
// $x = -45;
// echo is_int($x);
// $y = 30.56;
// echo is_float($y);
// echo PHP_FLOAT_MAX;
// $a = false;
// echo $a;
// $a = 10;
// $country = 'Bangladesh';
// $arr = [10,234,34,22,66];

?>