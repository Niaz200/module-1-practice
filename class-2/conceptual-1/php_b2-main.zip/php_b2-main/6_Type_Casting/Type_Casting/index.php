<?php
$a = "Bangladesh";
// $a = (int)$a;
var_dump($a);
// echo is_float($a);
// echo $a;
?>