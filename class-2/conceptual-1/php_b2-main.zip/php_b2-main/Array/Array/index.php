<?php
//$country_list = array("Bangladesh", "USA", "Canada");

//$country_list = ["Bangladesh", "USA", "Canada", "Australia", "England"];

// echo $country_list[0];
// echo $country_list[1];
// echo $country_list[2];
//echo count($country_list);

// for($i=0;$i<count($country_list);$i++) {
//     echo $country_list[$i].'<br>';
// }

// $numbers = [23,44,98,12,9,34,56,34,33,666,34,22,55];
// $total = 0;
// for($i=0;$i<count($numbers);$i++) {
//     $total = $total + $numbers[$i];
//     if($i==0) {
//         echo $numbers[$i];
//     } else {
//         echo ' + '.$numbers[$i];
//     }
// }
// echo ' = '.$total;

// $person = ["Arefin", "Bangladesh", 30];
// echo $person[0];
// echo $person[1];
// echo $person[2];

// $person = [
//     "fullname" => "Arefin", 
//     "country" => "Bangladesh", 
//     "age" => 30
// ];
// echo $person['fullname'];
// echo $person['country'];
// echo $person['age'];
// foreach($person as $key=>$value) {
//     echo 'Key is: ' . $key . ' and value is: ' . $value;
//     echo '<br>';
// }

// $person = [
//     ["Arefin", "Bangladesh", 30],
//     ["Peter", "Canada", 40],
//     ["Smith", "USA", 25]
// ];
// echo "Person 1 Name: " . $person[0][0].'<br>';
// echo "Person 1 Country: " . $person[0][1].'<br>';
// echo "Person 1 Age: " . $person[0][2].'<br>';

// echo "Person 2 Name: " . $person[1][0].'<br>';
// echo "Person 2 Country: " . $person[1][1].'<br>';
// echo "Person 2 Age: " . $person[1][2].'<br>';

// echo "Person 3 Name: " . $person[2][0].'<br>';
// echo "Person 3 Country: " . $person[2][1].'<br>';
// echo "Person 3 Age: " . $person[2][2].'<br>';

// for($i=0;$i<3;$i++) {
//     echo "Person ".($i+1)." Name: " . $person[$i][0].'<br>';
//     echo "Person ".($i+1)." Country: " . $person[$i][1].'<br>';
//     echo "Person ".($i+1)." Age: " . $person[$i][2].'<br>';
// }


// $person = [
//     [
//         "fullname" => "Arefin", 
//         "country" => "Bangladesh", 
//         "age" => 30
//     ],
//     [
//         "fullname" => "Peter", 
//         "country" => "Canada", 
//         "age" => 40
//     ],
//     [
//         "fullname" => "Smith", 
//         "country" => "USA", 
//         "age" => 25
//     ]
// ];
// echo $person[0]["fullname"];
// echo $person[1]["fullname"];
// echo $person[2]["fullname"];