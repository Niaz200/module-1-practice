<?php
// define("AUTHOR_NAME", "Morshedul Arefin");
// echo AUTHOR_NAME;

// define("cities", ["khulna","dhaka","rajshahi"]);
// echo cities[0];
// echo cities[1];
// echo cities[2];

define("AUTHOR_NAME", "Morshedul Arefin<br>");

function user_list() {
    echo AUTHOR_NAME;
}
user_list();

echo AUTHOR_NAME;

?>