<?php
echo $_REQUEST['name'];
echo $_REQUEST['age'];
?>