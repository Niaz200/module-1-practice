<?php
// function add() {
//     $a = 10;
//     $b = 20;
//     echo $a+$b;
// }
// add();

// function add() {
//     $a = 10;
//     $b = 20;
//     return $a+$b;
// }
// echo add();

// function add($a,$b) {
//     return $a+$b;
// }

// echo add(10,40);
// echo add(50,50);

// function add($a=0,$b=0,$c=0) {
//     return $a+$b+$c;
// }
// echo add();

// function pyramid($number) {
//     for($i=1;$i<=$number;$i++) {
//         for($j=1;$j<=$i;$j++) {
//             echo $j . ' ';
//         }
//         echo '<br>';
//     }
// }
// pyramid(3);
// pyramid(7);
// pyramid(9);

