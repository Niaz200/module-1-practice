<?php
echo "Bangladesh<br>";
echo "USA<br>";

require("another1.php");

echo "Australia<br>";