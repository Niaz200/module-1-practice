<?php
// Initialization
// Increment/Decrement
// Condition

// $a = 1;
// while($a < 10) {
//     echo "Bangladesh<br>";
//     $a++;
// }

// $a = 1;
// while(1) {
//     echo "Bangladesh<br>";
//     $a++;
//     if($a > 4) {
//         break;
//     }
// }

// $a = 1;
// do {
//     echo "Bangladesh<br>";
//     $a++;
// }while($a < 10);

// for($i=1;$i<=100;$i+=5) {
//     echo $i.' ';
// }
// i=1 1<=100 6 =  1
//     6<=100 11 = 6
//     11<=100 16 =  11

// $arr = array("usa","australia","canada");
// foreach($arr as $val) {
//     echo $val.'<br>';
// }

// $arr = array(
//     "username" => "arefin",
//     "age" => 30,
//     "password" => "1234"
// );
// foreach($arr as $key=>$val) {
//     echo "KEY is: " . $key . " and Value is: " . $val . '<br>';
// }

// $arr = array(12,34,55,77);
// for($i=0;$i<4;$i++) {
//     echo $arr[$i].'<br>';
// }



// for($i=1;$i<=10;$i++) {
    
//     if($i==5) {
//         break;
//     }

//     echo $i;
//     echo '<br>';
// }

// Even/Odd numbers
// 2 4 6 8 10
// for($i=1;$i<=100;$i++) {
//     if($i%2 != 0) {
//         echo $i.' ';
//     }
// }

