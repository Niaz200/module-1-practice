<?php
// echo pi();
// echo min(23,44,22,9,34);
// echo max(23,44,22,9,34);
// echo abs(-1234);
// echo sqrt(9);
// echo round(12.67978,2);
// echo round(12.6);
// echo round(12.4);
// echo round(12.98685,3);
// echo rand();
// echo rand(10,100);

// echo ceil(87.22343);
// echo floor(65.982394);

?>