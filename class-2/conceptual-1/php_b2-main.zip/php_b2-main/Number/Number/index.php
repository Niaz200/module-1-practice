<?php
//echo is_nan(sqrt(-12));

$a = "123";
var_dump(is_numeric($a));

?>