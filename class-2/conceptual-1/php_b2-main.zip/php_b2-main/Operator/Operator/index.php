<?php
// $a = 10;
// $b = 4;
// $c = $a + $b;
// $c = $a - $b;
// $c = $a * $b;
// $c = $a / $b;
// $c = $a ** $b;
// echo $c;

// $a = 10;
// $b = $a;
// echo $b;

// $x = 2;
// $x = $x + 4;
// $x += 4;
// echo $x;

//$x = 20;
// $x -= 4;
// $x *= 4;
//echo $x;

// $x = 10;
// $y = 30;
// $x += $y;
// $x = $x + $y;
// echo $x;

// $a = 30;
// $b = 10;
// var_dump($a==$b);
// var_dump($a===$b);
// var_dump($a!=$b);
// var_dump($a!==$b);
// var_dump($a>$b);
// var_dump($a<$b);
// var_dump($a>=$b);
// var_dump($a<=$b);
// var_dump($a<=>$b);

// $a = 10;
// $a = $a + 1;
// $a += 1;
// echo $a++;
// echo ++$a;
// echo $a--;
// echo --$a;
// echo $a;

// $a = 10;
// $b = 50;

// var_dump($a==10 and $b==20);
// var_dump($a==100 or $b==10);
// var_dump($a==10 xor $b==50);
// var_dump($a==10 && $b==50);
// var_dump($a==10 || $b==50);
// var_dump($a!=60);

// $s1 = "Bangladesh";
// $s2 = "Khulna";
// echo $s1.$s2;

// $str = "Bangladesh";
// $str .= "USA";
//$str = $str . "USA"
// echo $str;

// $arr1 = array(
//     'a' => 10,
//     'b' => 20
// );
// $arr2 = array(
//     'a' => 100,
//     'b' => 87
// );

//echo "<pre>";
// print_r($arr1+$arr2);
//print_r($arr1==$arr2);
//echo "</pre>";
// var_dump($arr1 == $arr2);
// var_dump($arr1 === $arr2);
// var_dump($arr1 != $arr2);
// var_dump($arr1 <> $arr2);
// var_dump($arr1 !== $arr2);

// $a = 80;
// echo ($a == 10) ? "This is true" : "This is false";

//$city = 'Khulna';

// echo $city = $city ?? "Dhaka";

?>