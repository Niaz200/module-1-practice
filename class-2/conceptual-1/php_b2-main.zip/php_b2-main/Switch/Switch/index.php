<?php
$country = "Canada";

switch($country) {
    
    case "Bangladesh":
        echo "You live in Bangladesh";
        break;

    case "USA":
        echo "You live in USA";
        break;

    case "Australia":
        echo "You live in Australia";
        break;

    default:
        echo "I do not know where you live";
}


?>